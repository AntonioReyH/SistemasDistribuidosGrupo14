Integrantes, Rol:
Cristobal Lazcano, 202173567-4
Antonio Rey, 202173633-6

Para ejecutar el programa, iniciar una terminal dentro de la carpeta "Laboratorio1Distro" y ejecutar el comando:
docker-compose up --build

O para ejecutar cada entidad es posible usar estos comandos:
make docker-marina
make docker-gobierno
make docker-cazarrecompenzas
make docker-submundo

A la hora de terminar este trabajo, el repositorio de github 'https://github.com/SistemasDistribuidos-2025-1/grupo-14' dispuesto
para nuestro grupo se encontraba fuera de servicio (Page not found), por lo que decidimos subir nuestro laboratorio 1 al
repositorio 'https://github.com/AntonioReyH/SistemasDistribuidosGrupo14', bajo la carpeta 'Lab1', para que quede registro de
cumplimiento.